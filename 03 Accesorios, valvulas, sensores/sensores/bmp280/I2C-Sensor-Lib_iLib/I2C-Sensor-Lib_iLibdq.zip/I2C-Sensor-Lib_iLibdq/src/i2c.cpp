//#ifdef WirePlus_h

/**<

TODO:   ugly BUGFIX!!!
        moved content directly to i2c.h ...
        to get Scripts without i2c down in filesize
        (i2c.cpp is loaded w/o request)

 */

//#endif

