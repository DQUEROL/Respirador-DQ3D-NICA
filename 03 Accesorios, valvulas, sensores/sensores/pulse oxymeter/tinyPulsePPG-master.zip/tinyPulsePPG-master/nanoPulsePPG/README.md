# arduinoPulsePPG

A version of tinyPulsePPG that runs on an Arduino AVR platform - tested on a Nano.

![breadboard](breadboard.jpg)
